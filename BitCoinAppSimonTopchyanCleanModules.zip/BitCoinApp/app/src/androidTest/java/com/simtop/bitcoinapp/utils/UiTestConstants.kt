package com.simtop.bitcoinapp.utils

const val MARKET_PRICE_RESPONSE_FILE_NAME = "ok_market_price_response.json"

const val SELECTED_DATE = "13 Nov"

const val TEST_ERROR = "HTTP 503 Server Error"
