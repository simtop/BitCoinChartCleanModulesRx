repositories {
    jcenter()
}

plugins {
    `kotlin-dsl`
}