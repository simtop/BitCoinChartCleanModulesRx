object Modules {
    const val app = ":app"
    const val domain = ":domain"
    const val data = ":data"
    const val test_utils = ":testutils"
}