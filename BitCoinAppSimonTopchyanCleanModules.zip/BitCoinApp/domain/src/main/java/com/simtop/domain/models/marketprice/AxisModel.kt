package com.simtop.domain.models.marketprice

data class AxisModel(
    val date: Long,
    val price: Float
)